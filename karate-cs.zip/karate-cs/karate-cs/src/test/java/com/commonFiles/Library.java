package com.commonFiles;

import net.minidev.json.JSONArray;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.Base64;
import java.io.UnsupportedEncodingException;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class Library {

    public int parseFeeInquiry(String Payin, JSONArray Response) {
        //String a =Response.get("AG").toString();
       int i;

        for (i = 0; i < Response.size(); ++i) {
            String tag = Response.get(i).toString();

            if (tag.contains("CreditCard") && Payin.contains("CreditCard")) {
                break;
            } else if (tag.contains("DebitCard") && Payin.contains("DebitCard")) {
                break;
            } else if (tag.contains("WUPay") && Payin.contains("WUPay")) {
                break;
            } else if (tag.contains("Sofort") && Payin.contains("Sofort")) {
                break;
            } else if (tag.contains("ACH") && Payin.contains("Bank")) {
                break;
            }else if (tag.contains("Cash") && Payin.contains("Cash")) {
                break;
            }

        }
        System.out.println(">>>>>>>>>>>>> Tag Location is : " + i);

        return i;
    }

    public String getBase64Encode(Map LBPMap) {

        String base64encodedString = null;
        String LBPjson = LBPMap.get("LBPJson").toString();
        LBPjson = LBPjson.replaceAll("\\r\\n", "\n");
        LBPjson = LBPjson.replaceAll("\\r", "\n");

        try {
            base64encodedString = Base64.getEncoder().encodeToString(LBPjson.getBytes("UTF-8"));

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        System.out.println("\n" + base64encodedString + "\n");
        return base64encodedString;
    }

    public  String getRefID(String token) {
        return token.split(":")[0];
    }

    public  String generateHMAC(String token) {
        Mac sha512_HMAC = null;
        String result = null;
        String key = null;
        key = "ba915298476a42941b3455796f30392baf2b554af70e2982e4a0559a76a43c1b";
        try {
            byte[] byteKey = key.getBytes("UTF-8");
            final String HMAC_SHA512 = "HmacSHA256";
            sha512_HMAC = Mac.getInstance(HMAC_SHA512);
            SecretKeySpec keySpec = new SecretKeySpec(byteKey, HMAC_SHA512);
            sha512_HMAC.init(keySpec);
            System.out.println("HMAC_SHA512 " + HMAC_SHA512);
            byte[] mac_data = sha512_HMAC.doFinal(token.getBytes("UTF-8"));
            //result = Base64.encode(mac_data);
            final char[] hexArray = "0123456789ABCDEF".toCharArray();
            char[] hexChars = new char[mac_data.length * 2];
            for (int j = 0; j < mac_data.length; j++) {
                int v = mac_data[j] & 0xFF;
                hexChars[j * 2] = hexArray[v >>> 4];
                hexChars[j * 2 + 1] = hexArray[v & 0x0F];
            }
             result = new String(hexChars);
            result = Base64.getEncoder().encodeToString(mac_data);
            System.out.println("Inside Hmac " + result);

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        }
        return result;
    }

    public String priceQuoteBreakUp(String Payin, String PayOut, LinkedHashMap Response) {
        //String a =Response.get("AG").toString();
        int i;
        String result = "";
        result = Response.toString();
        System.out.println("--->>>>>####>>>> Response.size() : " + Response.size());

        for (i = 0; i < Response.size(); ++i) {
            String tag = Response.get(i).toString();
            System.out.println(">>>>>>>>>>>>> Tag Value : " + tag);
//            if (tag.contains("CreditCard")&& Payin.contains("CreditCard")) {
//                break;
//            } else if (tag.contains("DebitCard")&& Payin.contains("DebitCard")) {
//                break;
//            } else if (tag.contains("WUPay")&& Payin.contains("WUPay")) {
//                break;
//            } else if (tag.contains("Sofort")&& Payin.contains("Sofort")) {
//                break;
//            } else if (tag.contains("ACH")&& Payin.contains("Bank")) {
//                break;
//            }
        }
//        System.out.println(">>>>>>>>>>>>> Tag Location is : " +i);

        return result;
    }

    public int PriceQuoteCheck(String Payin, String PayOut, JSONArray Response) {
        int i = 0;
        System.out.println("InSide PriceQuoteCheck \n :" + Response);
        System.out.println("Size: " + Response.size());

        PayOut = PayOut.toUpperCase();

        for (i = 0; i < Response.size(); ++i) {
            String tag = Response.get(i).toString().toUpperCase();

            if (tag.contains("MONEY IN MINUTES") && PayOut.contains("CASH")) {
                System.out.println(">>>>> MoneyIn Minutes found");
                System.out.println("Tag is " + tag);
                break;
            }
            if (tag.contains("DIRECT TO BANK") && (PayOut.contains("D2B") || PayOut.contains("BANK"))) {
                System.out.println(">>>>> Direct to Bank Found");
                System.out.println("Tag is " + tag);
                break;
            }
            if (tag.contains("MOBILE MONEY TRANSFER") && (PayOut.contains("MT") || PayOut.contains("MOBILE"))) {
                System.out.println(">>>>> Mobile Money Transfer found");
                System.out.println("Tag is " + tag);
                break;
            }

        }
        return i;
    }

    public int PriceQuoteTag(String Payin, JSONArray Response) {
        int i = 0;

        Payin = Payin.toUpperCase();
        System.out.println("InSide PriceQuoteTag \n :" + Response);
        System.out.println("Size: " + Response.size());

        for (i = 0; i < Response.size(); ++i) {
            String tag = Response.get(i).toString().toUpperCase();

            if (tag.contains("CREDITCARD") && (Payin.contains("CREDITCARD") || Payin.contains("CC"))) {
                System.out.println("**Found CreditCard");
                System.out.println("Tag is " + tag);
                break;
            }

            if (tag.contains("SOFORT") && Payin.contains("SOFORT")) {
                System.out.println("**Found Sofort Tag");
                System.out.println("Tag is " + tag);
                break;
            }

            if (tag.contains("WUPAY") && Payin.contains("WUPAY")) {
                System.out.println("**Found WUPay Tag");
                System.out.println("Tag is " + tag);
                break;
            }

        }
        return i;
    }

    public String findPriceQuoteValue(String sContext, String sKey) {
        String finalvalue = "";

        if (sKey.contains("productcode")) {
            String pricingcontext[] = sContext.split("/");
            finalvalue = pricingcontext[7];
            System.out.println("productcode is " + finalvalue);

        }

        if (sKey.contains("routingcode")) {
            String pricingcontext[] = sContext.split("/");
            finalvalue = pricingcontext[8];
            System.out.println("routingcode is " + finalvalue);
        }
        if (sKey.contains("feeamount")) {
//            sContext = "10.00,1.23;20.00,2.00";
            String feemetaSemi[] = sContext.split(",");
            String feemeta[] = feemetaSemi[1].split(";");
            Float feeValue = (Float.parseFloat(feemeta[0])) * 100;
            Integer FeeInt = Math.round(feeValue);
            finalvalue = FeeInt.toString();
            System.out.println("Charges or feeAmount is " + finalvalue);
        }
        if (sKey.contains("feerate")) {
//            sContext = "999999.00,1.234562";
            String feeconversionsemi[] = sContext.split(",");
            String feeConv[] = feeconversionsemi[1].split(";");
            Float feeConversion = (Float.parseFloat(feeConv[0]));
            System.out.println("feeConversion is " + feeConversion);
            Integer feeConversion1 = (Math.round(feeConversion * 10000));
            System.out.println("feeConversion1 is " + feeConversion1);

            Float feeConversion2 = (Float.parseFloat(feeConversion1.toString())) / 10000;
            finalvalue = feeConversion2.toString();
            System.out.println("feeExchangeRate is " + finalvalue);
        }
        return finalvalue;
    }

    public Integer calculateAmount(String principalAmount, String secondAmount, String sKey) {
        Integer calAmount = 0;
        if (sKey.toUpperCase().contains("GROSS")) {
            Float calAmount1 = Float.parseFloat(principalAmount) * 100 + Float.parseFloat(secondAmount); // secondAmount is charges in case of gross amount caluclation
            calAmount = Math.round(calAmount1);
            System.out.println("GROSS amount is " + calAmount);

        }
        if (sKey.toUpperCase().contains("EXPECTED")) {
            System.out.println("exchangerate  is " + secondAmount);
            Float secamount1 = (Float.parseFloat(secondAmount)); // secondAmount is exchangerate in case of expectedpayout amount caluclation
            Integer secamount2 = (Math.round(secamount1 * 100));
            Float secamount3 = (Float.parseFloat(secamount2.toString())) / 100;
            System.out.println("secamount3 ::: " + secamount3);

            Integer secamount31 = (Math.round(secamount3 * 10));
            System.out.println("secamount31 is " + secamount31);

            Float roundedSecAmount = (Float.parseFloat(secamount31.toString())) / 10;

            Float princi = Float.parseFloat(principalAmount) * 100;
            Float factor1 = princi * roundedSecAmount;
            calAmount = Math.round(factor1);
            System.out.println("EXPECTED amount is " + calAmount);
        }

        return calAmount;
    }

    public String getServiceEndPoint(String serviceName) {

        String endpoint = null;

        switch (serviceName) {
            case "CreateSession":
                endpoint = "/rest/api/v1.0/CreateSession";
                break;
            case "RegisterCustomerValidation":
                endpoint = "/rest/api/v1.0/RegisterCustomerValidation";
                break;
            case "RegisterCustomer":
                endpoint = "/rest/api/v1.0/RegisterCustomer";
                break;
            case "ValidateToken":
                endpoint = "/rest/api/v1.0/ValidateToken";
                break;
            case "CustomerSignOn":
                endpoint = "/rest/api/v1.0/CustomerSignOn";
                break;
            case "GetLimits":
                endpoint = "/rest/api/v1.0/GetLimits";
                break;
            case "GetBillers":
                endpoint = "/rest/api/v1.0/GetBillers";
                break;
            case "GetBanks":
                endpoint = "/rest/api/v1.0/GetBanks";
                break;
            case "AddBanks":
                endpoint = "/rest/api/v1.0/AddBanks";
                break;
            case "FeeInquiryEstimated":
                endpoint = "/rest/api/v1.0/FeeInquiryEstimated";
                break;
            case "AddReceivers":
                endpoint = "/rest/api/v1.0/AddReceivers";
                break;
            case "AddCreditCards":
                endpoint = "/rest/api/v1.0/AddCreditCards";
                break;
            case "GetCreditCards":
                endpoint = "/rest/api/v1.0/GetCreditCards";
                break;
            case "UpdateCustomerProfile":
                endpoint = "/rest/api/v1.0/UpdateCustomerProfile";
                break;
            case "UpdateCompliance":
                endpoint = "/rest/api/v1.0/IDCompliance/UpdateCompliance";
                break;
            case "SendMoneyValidation":
                endpoint = "/rest/api/v1.0/SendMoneyValidation";
                break;
            case "SendMoneyStore":
                endpoint = "/rest/api/v1.0/SendMoneyStore";
                break;
            case "GetTransactionDetails":
                endpoint = "/rest/api/v1.0/GetTransactionDetails";
                break;
            case "AuthenticateCustomer":
                endpoint = "/rest/api/v1.0/AuthenticateCustomer";
                break;
            case "GetCustomerVerificationStatus":
                endpoint = "/rest/api/v1.0/GetCustomerVerificationStatus";
                break;
            case "GetCompliance":
                endpoint = "/rest/api/v1.0/IDCompliance/GetCompliance";
                break;
            case "GetReceivers":
                endpoint = "/rest/api/v1.0/GetReceivers";
                break;
            case "DeleteCreditCards":
                endpoint = "/rest/api/v1.0/DeleteCreditCards";
                break;
            case "GetCustomerProfile":
                endpoint = "/rest/api/v1.0/GetCustomerProfile";
                break;
            case "ChangePassword":
                endpoint = "/rest/api/v1.0/ChangePassword";
                break;
            case "GetCurrencies":
                endpoint = "/rest/api/v1.0/GetCurrencies";
                break;
            case "TransactionInquiry":
                endpoint = "/rest/api/v1.0/TransactionInquiry";
                break;
            case "EmailValidation":
                endpoint = "/rest/api/v1.0/EmailValidation";
                break;
            case "InitiateCustomerVerification":
                endpoint = "/rest/api/v1.0/InitiateCustomerVerification";
                break;
            case "PriceQuote":
                endpoint = "/rest/api/v1.0/price/quote";
                break;
            case "UploadDMSDoc":
                endpoint = "/rest/api/v1.0/UploadDMSDoc";
                break;
            case "GetTransactionHistory":
                endpoint = "/rest/api/v1.0/GetTransactionHistory";
                break;
            case "VerifyCustomer":
                endpoint = "/rest/api/v1.0/VerifyCustomer";
                break;
            case "PriceCorridors":
                 endpoint ="/rest/api/v1.0/price/corridors";
                 break;
            case "BankLists":
                endpoint ="/rest/api/v1.0/BankLists";
                break;
            case "CustomerLookup":
                endpoint ="/rest/api/v1.0/CustomerLookup";
                break;
            case "DSSGetCustomerStatus":
                endpoint ="/rest/channel/GwpGetCustomerStatus";
                break;
            case "DSSAuthenticateCustomer":
                endpoint = "/rest/channel/AuthenticateCustomer";
                break;
            case "DSSGetQuestionaire&PendingDocs":
                endpoint = "/rest/channel/GetQuestionnaireAndPendingDocs";


        }

        return endpoint;
    }

}

