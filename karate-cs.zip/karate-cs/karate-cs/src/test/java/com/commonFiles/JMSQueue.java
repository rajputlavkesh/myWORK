package com.commonFiles;

import com.tibco.tibjms.TibjmsQueue;
import org.apache.commons.io.FileUtils;

import javax.jms.*;
import java.io.File;
import java.util.Map;

public class JMSQueue {

    static String serverUrl = "tcp://10.45.234.228:7000";
    static String userName = "digitalUser";
    static String password = "zE@IU\\s2fZiA";

    public void connectWithJMS(Map mapValues) {
        System.out.println("--- inside this--");
        Connection connection = null;
        Session session = null;
        MessageProducer msgProducer = null;
        Destination destination = null;
        try {
            //File file = new File("OSNFile.txt");
            String cwd = System.getProperty("user.dir");
            System.out.println(cwd);
            String queueName = "";
            String payload = "";
            String remainingFilePath = "\\src\\test\\java\\com\\commonFiles\\";
            String psn = mapValues.get("psn").toString();
            if (psn.equalsIgnoreCase("QAPSN")) {
                String path = cwd + remainingFilePath + "OSNFiles.txt";
                payload = FileUtils.readFileToString(new File(path), "UTF-8");
                payload = payload.replaceAll("OrderCodeValue", mapValues.get("externalRefID").toString());
                payload = payload.replaceAll("GatewayCodeValue", mapValues.get("processor").toString());
                payload = payload.replaceAll("LastEventValue", mapValues.get("status").toString());
                System.out.println(payload);
                queueName = "WU.QA.PROVIDERS.WUDPAYMENTGATEWAY.PAYMENT.STATUS.NOTIFICATION.QUEUE";
            } else if (psn.equalsIgnoreCase("QAREFUND")) {
                String path = cwd + remainingFilePath +"RefundNotification.txt";
                payload = FileUtils.readFileToString(new File(path), "UTF-8");
                payload = payload.replaceAll("OrderCode", mapValues.get("externalRefID").toString());
                payload = payload.replaceAll("amt", mapValues.get("amount").toString());
                payload = payload.replaceAll("currencyCode", mapValues.get("currencyCode").toString());
                System.out.println(payload);
                queueName = "WU.QA.CORE.WUDPAYMENTGATEWAY.CANCEL.REFUND.REQUEST.QUEUE";
            }

            TextMessage msg;
            ConnectionFactory factory = new com.tibco.tibjms.TibjmsConnectionFactory(
                    serverUrl);
            connection = factory.createConnection(userName, password);
            System.out.println(connection);
            session = connection
                    .createSession(false, javax.jms.Session.AUTO_ACKNOWLEDGE);
            System.out.println(session);

            destination = new TibjmsQueue(queueName);
            msgProducer = session.createProducer(null);
            msg = session.createTextMessage();

            msg.setText(payload);
            msgProducer.send(destination, msg);
            connection.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
