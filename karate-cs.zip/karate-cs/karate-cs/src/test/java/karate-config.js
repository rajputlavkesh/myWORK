function() {

var env = karate.env;

if (!env)
{
   env = 'QA21';
   karate.log('Environment not set =', karate.env);
}

var config = {
    env: env,
    baseUrl: 'https://wudispatcher-uatrs3.westernunion.com/presentationservice',
    retailURL: 'https://wudispatcher-uatrs7.westernunion.com/presentationservice',
    retry : { count: 2, interval: 90000 },
  }

  switch (env) {
              case "UATRS2":
                      config.baseUrl = 'https://wudispatcher-uatrs2.westernunion.com/wuconnect';
                      config.retailURL = 'https://wudispatcher-uatrs5.westernunion.com/presentationservice';
                      break;
              case "UATRS3":
                      config.baseUrl = 'https://wudispatcher-uatrs3.westernunion.com/presentationservice';
                      config.retailURL = 'https://wudispatcher-uatrs7.westernunion.com/presentationservice';
                      break;
              case "UATRS4":
                      config.baseUrl = 'https://wudispatcher-uatrs4.westernunion.com/presentationservice';
                      config.retailURL = 'https://wudispatcher-uatci5.westernunion.com/presentationservice';
                      break;
              case "PRODCI":
                       config.baseUrl = 'https://wudispatcherci.westernunion.com/wuconnect';
                       config.retailURL = 'https://wudispatcherci.westernunion.com/retailpresentationservice';
                       break;
              case "PRODRS":
                       config.baseUrl = 'https://wudispatcherrs.westernunion.com/wuconnect';
                       config.retailURL = 'https://wudispatcherrs.westernunion.com/retailpresentationservice';
                       break;
              case "WU":
                       config.baseUrl = 'https://www.westernunion.com/wuconnect';
                       config.retailURL = 'https://www.westernunion.com/retailpresentationservice';
                       break;
              case "FOUNDATIONCI":
                      config.baseUrl = 'https://wudgtsrvsci.prod.wudip.com/wudgtsrvs';
                      config.retailURL = 'https://wudgtsrvsci.prod.wudip.com/wudgtsrvs';
                      break;
              case "FOUNDATIONRS":
                      config.baseUrl = 'https://wudgtsrvsrs.prod.wudip.com/wudgtsrvs';
                      config.retailURL = 'https://wudgtsrvsrs.prod.wudip.com/wudgtsrvs';
                      break;
              case "FOUNDATIONRS3":
                      config.baseUrl = 'https://wudispatcher-uatrs3.westernunion.com/wudgtsrvs';
                      config.retailURL = 'https://wudispatcher-uatrs3.westernunion.com/wudgtsrvs';
                      break;
              case "FOUNDATIONRS4":
                      config.baseUrl = 'https://wudispatcher-uatrs4.westernunion.com/wudgtsrvs';
                      config.retailURL = 'https://wudispatcher-uatrs4.westernunion.com/wudgtsrvs';
                      break;
               case "PARTNER":
                      config.baseUrl = 'https://partners-sandbox.westernunion.com/wuconnect';
                      break;
               case "QA21":
                       config.retailURL = 'https://wuretailsrvs-qa21.qawesternunion.com/wudgtsrvs/retail'
                       config.retailURL1= 'https://wuretailsrvs-qa21.qawesternunion.com/wudgtsrvs/mobiliser'
                       config.baseUrl = 'https://wudispatcher-qa11.qawesternunion.com/wuconnect'
          }

   karate.log('karate.env =', karate.env);
   karate.configure('connectTimeout', 60000);
   karate.configure('readTimeout', 100000);
   karate.log('config.baseUrl =', config.baseUrl);
   return config;

}